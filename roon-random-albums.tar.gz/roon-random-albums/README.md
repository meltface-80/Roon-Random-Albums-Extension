# Random Albums — a Roon extension

A web UI that shows a screenful of random albums from your Roon library, with
**Play Now**, **Add to Queue**, **Play Next**, **Shuffle**, and **Start Radio**
actions targeting any of your zones. Refresh button reshuffles the wall.
Roon-style dark theme (default) plus a light theme.

> The Roon API does not let third-party code navigate the Roon app itself, so
> the album detail view (art, tracks, action buttons) is rendered inside this
> UI. Tapping **Play Now** still plays through Roon on the zone you select.

## Requirements

- A machine running Roon Server (tested on DietPi).
- **Node.js 18 or newer.** Check with `node -v`.
- **git** (npm needs it to fetch the Roon API libraries from GitHub).

Install missing prerequisites:

```bash
# DietPi / Debian / Ubuntu
sudo apt-get update
sudo apt-get install -y git
# If Node is missing or too old:
sudo dietpi-software install 9     # DietPi
# or use NodeSource on plain Debian/Ubuntu
```

## Install

```bash
# 1. Put the project somewhere persistent
sudo mkdir -p /opt/roon-random-albums
sudo chown $USER:$USER /opt/roon-random-albums
# Copy roon-random-albums.tar.gz to the box, then:
mv ~/roon-random-albums.tar.gz /opt/
cd /opt
tar -xzf roon-random-albums.tar.gz
cd roon-random-albums

# 2. Install dependencies (needs internet + git)
npm install

# 3. Run it
node index.js
```

You should see:

```
Roon Random Albums UI listening on http://0.0.0.0:3399
Make sure to authorise the extension in Roon → Settings → Extensions.
```

Now:

1. Open any Roon remote.
2. **Settings → Extensions** — you'll see **Random Albums**. Click **Enable**.
3. Browse to `http://<your-server-ip>:3399`.
4. Pick a zone in the top-right, tap albums to play / queue.

You only authorise once; subsequent launches reconnect automatically.

## Run as a systemd service (autostart on boot)

Create `/etc/systemd/system/roon-random-albums.service`:

```ini
[Unit]
Description=Roon Random Albums
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/roon-random-albums
ExecStart=/usr/bin/node /opt/roon-random-albums/index.js
Restart=on-failure
RestartSec=5
User=root
Environment=NODE_ENV=production
# Change port if 3399 clashes:
# Environment=PORT=3399

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now roon-random-albums
sudo systemctl status roon-random-albums
journalctl -u roon-random-albums -f          # live logs
```

## Sharing with others — make a self-contained tarball

Once you've successfully run `npm install`, you can build a tarball that
includes `node_modules`, so recipients don't need internet or git:

```bash
cd /opt
tar -czf roon-random-albums-bundled.tar.gz roon-random-albums/
```

Recipients then only need Node.js:

```bash
tar -xzf roon-random-albums-bundled.tar.gz
cd roon-random-albums
node index.js
```

## Configuration

| Env var     | Default | What it does |
|-------------|---------|--------------|
| `PORT`      | `3399`  | HTTP port the UI listens on |
| `RRA_DEBUG` | —       | Set to `1` for verbose logging |

### Album metadata sources

No keys required. The extension pulls in three pieces of external metadata:

- **Release year** — MusicBrainz (free, public API).
- **Album editorial review** — scraped from the public Qobuz album page when
  it exists; falls back to the Wikipedia article's intro paragraph.
- **Artist bio** — Wikipedia article intro.

Each source's results are independently checked against the album title and
artist name before being shown. If a match can't be found, the section is
simply hidden instead of showing data for the wrong album.

> **Caveat:** Qobuz has no official public API, so this uses light HTML
> scraping. If Qobuz changes their page markup, the review section may stop
> working — Wikipedia will still cover most albums.

The "screenful" album count is computed client-side from viewport size, so it
adapts between phones, tablets, and desktop browsers automatically.

## Customising

- **Albums per screen**: edit `computeAlbumCount()` in `public/app.js`. Cap is
  96, enforced server-side in `index.js`.
- **Image size**: change `size=500` / `size=800` query params in
  `public/app.js`. Larger = sharper, slower.
- **Action button order**: edit the `order` array in `public/app.js`.

## Troubleshooting

- **`npm install` fails with `git: command not found`**
  → `sudo apt-get install -y git`, then re-run.
- **`npm install` 404s on `node-roon-api`**
  → Your `package.json` still has the old `^1.0.0` versions. The fixed file
  uses `github:RoonLabs/...` references. Re-extract the tarball.
- **"Waiting for Roon Core" never goes away**
  → Roon → Settings → Extensions → click **Enable** on *Random Albums*.
- **Play Now does nothing**
  → Confirm a real zone is selected in the dropdown.
- **"No zones available"**
  → No active outputs visible to Roon yet. Wake a device or pick one in
  Roon's own remote first.

## File layout

```
roon-random-albums/
├── package.json
├── index.js                # Roon API + Express server
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── README.md
```
