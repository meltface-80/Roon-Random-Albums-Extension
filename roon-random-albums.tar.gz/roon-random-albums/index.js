// roon-random-albums  —  random-album wall extension for Roon
// Runs alongside Roon Server, exposes a web UI on http://<host>:3399

const path = require("path");
const express = require("express");

const RoonApi          = require("node-roon-api");
const RoonApiStatus    = require("node-roon-api-status");
const RoonApiBrowse    = require("node-roon-api-browse");
const RoonApiImage     = require("node-roon-api-image");
const RoonApiTransport = require("node-roon-api-transport");

const PORT       = parseInt(process.env.PORT || "3399", 10);
const ALBUM_COUNT_DEFAULT = 24;
const DEBUG      = process.env.RRA_DEBUG === "1";

// ---------------------------------------------------------------------------
// Roon extension setup
// ---------------------------------------------------------------------------
let core      = null;
let zones     = {};
let outputs   = {};

const roon = new RoonApi({
  extension_id:        "com.local.roon.random-albums",
  display_name:        "Random Albums",
  display_version:     "1.0.1",
  publisher:           "self",
  email:               "you@example.com",
  log_level:           "none",

  core_paired: function (c) {
    core = c;
    svc_status.set_status("Paired with " + c.core_id, false);
    c.services.RoonApiTransport.subscribe_zones((cmd, data) => {
      if (cmd === "Subscribed") {
        zones = {}; outputs = {};
        (data.zones || []).forEach(z => {
          zones[z.zone_id] = z;
          (z.outputs || []).forEach(o => { outputs[o.output_id] = o; });
        });
      } else if (cmd === "Changed") {
        (data.zones_added   || []).forEach(z => { zones[z.zone_id] = z;
          (z.outputs || []).forEach(o => { outputs[o.output_id] = o; }); });
        (data.zones_changed || []).forEach(z => { zones[z.zone_id] = z;
          (z.outputs || []).forEach(o => { outputs[o.output_id] = o; }); });
        (data.zones_removed || []).forEach(zid => {
          const z = zones[zid];
          if (z) (z.outputs || []).forEach(o => delete outputs[o.output_id]);
          delete zones[zid];
        });
      }
    });
  },
  core_unpaired: function () {
    core = null; zones = {}; outputs = {};
    svc_status.set_status("Not paired with any Roon Core", true);
  }
});

const svc_status = new RoonApiStatus(roon);
roon.init_services({
  required_services: [RoonApiTransport, RoonApiBrowse, RoonApiImage],
  provided_services: [svc_status]
});
svc_status.set_status("Starting...", false);
roon.start_discovery();

// ---------------------------------------------------------------------------
// Promisified Roon calls
// ---------------------------------------------------------------------------
function browse(opts) {
  return new Promise((resolve, reject) => {
    if (!core) return reject(new Error("Not paired with a Roon Core yet"));
    if (DEBUG) console.log("[browse]", JSON.stringify(opts));
    core.services.RoonApiBrowse.browse(opts, (err, body) => {
      if (err) return reject(new Error(typeof err === "string" ? err : JSON.stringify(err)));
      if (DEBUG) console.log("[browse:res]", body && body.action, body && body.list && body.list.title);
      resolve(body);
    });
  });
}
function load(opts) {
  return new Promise((resolve, reject) => {
    if (!core) return reject(new Error("Not paired with a Roon Core yet"));
    if (DEBUG) console.log("[load]", JSON.stringify(opts));
    core.services.RoonApiBrowse.load(opts, (err, body) => {
      if (err) return reject(new Error(typeof err === "string" ? err : JSON.stringify(err)));
      if (DEBUG) console.log("[load:res]", body && body.list && body.list.title,
                            "items:", (body && body.items || []).length);
      resolve(body);
    });
  });
}
function getImage(image_key, opts) {
  return new Promise((resolve, reject) => {
    if (!core) return reject(new Error("Not paired with a Roon Core yet"));
    core.services.RoonApiImage.get_image(image_key, opts, (err, content_type, body) =>
      err ? reject(new Error(typeof err === "string" ? err : JSON.stringify(err)))
          : resolve({ content_type, body }));
  });
}


// ---------------------------------------------------------------------------
// Pick N random albums.  Each session is dedicated to one operation so
// item_keys never leak across requests — instead we always re-resolve from
// the album offset, which is stable as long as the library isn't changing.
// ---------------------------------------------------------------------------
async function pickRandomAlbums(count) {
  const sessionKey = "rra_pick_" + Math.random().toString(36).slice(2, 10);

  await browse({ hierarchy: "albums", pop_all: true, multi_session_key: sessionKey });

  const head = await load({
    hierarchy: "albums", offset: 0, count: 1, multi_session_key: sessionKey
  });
  const total = head.list && head.list.count ? head.list.count : 0;
  if (total === 0) return [];

  const want = Math.min(count, total);
  const picked = new Set();
  while (picked.size < want) picked.add(Math.floor(Math.random() * total));
  const offsets = [...picked];

  const albums = [];
  for (const off of offsets) {
    try {
      const r = await load({
        hierarchy: "albums", offset: off, count: 1, multi_session_key: sessionKey
      });
      const item = r.items && r.items[0];
      if (item) {
        albums.push({
          offset:    off,
          title:     item.title || "",
          subtitle:  item.subtitle || "",
          image_key: item.image_key || null
        });
      }
    } catch (e) {
      if (DEBUG) console.error("load offset", off, "failed:", e.message);
    }
  }
  return albums;
}

// ---------------------------------------------------------------------------
// Resolve an album by offset, drill in, and return action menu + tracks.
// Optionally invokes one of the actions (kind) against a zone.
// ---------------------------------------------------------------------------
async function openAlbumByOffset(offset, zoneOrOutputId, invokeKind) {
  const sessionKey = "rra_open_" + Math.random().toString(36).slice(2, 10);

  // 1) Fresh albums hierarchy
  await browse({ hierarchy: "albums", pop_all: true, multi_session_key: sessionKey });

  // 2) Re-resolve THIS session's item_key for the album at `offset`
  const albumLoad = await load({
    hierarchy: "albums", offset, count: 1, multi_session_key: sessionKey
  });
  const albumItem = albumLoad.items && albumLoad.items[0];
  if (!albumItem) throw new Error("Album not found at offset " + offset);

  const albumInfo = {
    title:     albumItem.title || "",
    subtitle:  albumItem.subtitle || "",
    image_key: albumItem.image_key || null
  };

  // 3) Drill into the album
  const drill = await browse({
    hierarchy: "albums",
    item_key:  albumItem.item_key,
    multi_session_key: sessionKey
  });
  if (drill.action !== "list") {
    throw new Error("Unexpected browse action: " + drill.action);
  }

  // 4) Load contents (tracks + action_list).  Explicit count for big albums.
  const inside = await load({
    hierarchy: "albums",
    offset: 0,
    count: 500,
    multi_session_key: sessionKey
  });

  const items = inside.items || [];
  if (DEBUG) {
    console.log("[album items]");
    for (const it of items) {
      console.log("  - hint=" + (it.hint || "<none>") + "  title=" + JSON.stringify(it.title));
    }
  }

  // 5) Find the Play submenu.  In Roon's "albums" hierarchy, BOTH the Play
  //    Album action AND each track come back with hint "action_list" (tapping
  //    a track opens its own submenu).  We tell them apart by the subtitle:
  //    tracks have an artist/composer credit; submenu actions do not.
  const playMenu = items.find(i =>
       i.hint === "action_list" && !i.subtitle && /^play/i.test(i.title || "")
  ) || items.find(i =>
       i.hint === "action_list" && !i.subtitle
  );

  // 6) Tracks = items that aren't the play menu, a no-subtitle submenu
  //    (e.g. "Add to Library"), or a section header.  Strip Roon's leading
  //    "N. " from titles because the UI renders its own counter.
  const tracks = items
    .filter(t => {
      if (t === playMenu)                          return false;
      if (t.hint === "action_list" && !t.subtitle) return false;
      if (t.hint === "header")                     return false;
      return true;
    })
    .map(t => ({
      title:    (t.title || "").replace(/^\d+\.\s+/, ""),
      subtitle: t.subtitle || ""
    }));

  let actions = [];
  if (playMenu) {
    // Drill into Play menu
    await browse({
      hierarchy: "albums",
      item_key:  playMenu.item_key,
      multi_session_key: sessionKey
    });
    const acts = await load({ hierarchy: "albums", multi_session_key: sessionKey });
    actions = (acts.items || []).map(a => ({
      item_key: a.item_key,
      title:    a.title || "",
      hint:     a.hint  || "",
      kind:     classifyAction(a.title)
    }));
  }

  // 7) Optionally invoke one
  let invoked = null;
  if (invokeKind) {
    const action = matchAction(actions, invokeKind);
    if (!action) {
      throw new Error("No matching action for '" + invokeKind +
                      "'. Available: " + actions.map(a => a.title).join(", "));
    }
    if (!zoneOrOutputId) throw new Error("zone_or_output_id required to invoke an action");
    await browse({
      hierarchy: "albums",
      item_key:  action.item_key,
      zone_or_output_id: zoneOrOutputId,
      multi_session_key: sessionKey
    });
    invoked = action.title;
  }

  return { album: albumInfo, tracks, actions, invoked };
}

function classifyAction(title) {
  const t = (title || "").toLowerCase();
  if (/play\s*now/.test(t))            return "play_now";
  if (/add\s*next|play\s*next/.test(t))return "play_next";
  if (/queue/.test(t))                 return "queue";
  if (/shuffle/.test(t))               return "shuffle";
  if (/radio/.test(t))                 return "radio";
  return "other";
}
function matchAction(actions, kind) {
  return actions.find(a => a.kind === kind)
      || (kind === "play_now" ? actions.find(a => /^play/i.test(a.title)) : null);
}

// ---------------------------------------------------------------------------
// External metadata: MusicBrainz (release year), Qobuz + Wikipedia (bios).
// Qobuz is preferred (rich editorial reviews) with Wikipedia as fallback.
// Both candidates are verified against the album+artist name before display.
// No API keys required.
// ---------------------------------------------------------------------------
const MB_USER_AGENT = process.env.MB_USER_AGENT ||
  "RoonRandomAlbums/1.1.0 (Roon extension)";
const BROWSER_UA =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

const mbCache    = new Map();
const qobuzCache = new Map();
const wikiCache  = new Map();
let mbLastReq    = 0;
let qobuzLastReq = 0;

async function mbWait() {
  const elapsed = Date.now() - mbLastReq;
  if (elapsed < 1100) await new Promise(r => setTimeout(r, 1100 - elapsed));
  mbLastReq = Date.now();
}
async function qobuzWait() {
  const elapsed = Date.now() - qobuzLastReq;
  if (elapsed < 700) await new Promise(r => setTimeout(r, 700 - elapsed));
  qobuzLastReq = Date.now();
}

async function httpJson(url, headers, timeoutMs = 8000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers, signal: ctl.signal });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}
async function httpText(url, headers, timeoutMs = 12000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers, signal: ctl.signal, redirect: "follow" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function normalize(s) {
  return String(s || "").toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
function stripHtml(html) {
  return String(html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<br\s*\/?\s*>/gi, "\n")
    .replace(/<\/?p[^>]*>/gi, "\n\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#0?39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&[rl]squo;/g, "'")
    .replace(/&[rl]dquo;/g, '"')
    .replace(/&hellip;/g, "...")
    .replace(/&mdash;/g, "—")
    .replace(/&ndash;/g, "–")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]+/g, " ")
    .trim();
}

// MusicBrainz: release year
function mbQuote(s) {
  return String(s).replace(/[+\-&|!(){}\[\]^"~*?:\\\/]/g, "\\$&");
}
async function fetchAlbumYear(title, artist) {
  if (!title) return null;
  const key = normalize(title) + "||" + normalize(artist || "");
  if (mbCache.has(key)) return mbCache.get(key);
  await mbWait();
  let q = `release:"${mbQuote(title)}"`;
  if (artist) q += ` AND artist:"${mbQuote(artist)}"`;
  const url = `https://musicbrainz.org/ws/2/release-group/?query=${encodeURIComponent(q)}&fmt=json&limit=5`;
  try {
    const json = await httpJson(url, { "User-Agent": MB_USER_AGENT });
    const rgs = json["release-groups"] || [];
    rgs.sort((a, b) =>
      (a["first-release-date"] || "9999").localeCompare(b["first-release-date"] || "9999"));
    const date = rgs[0] && rgs[0]["first-release-date"] || null;
    const year = date ? date.slice(0, 4) : null;
    mbCache.set(key, year);
    return year;
  } catch (e) {
    if (DEBUG) console.error("[mb]", e.message);
    mbCache.set(key, null);
    return null;
  }
}

// Qobuz: search the public site, scrape the editorial review off the album page.
async function fetchQobuz(title, artist) {
  if (!title) return null;
  const key = normalize(title) + "||" + normalize(artist || "");
  if (qobuzCache.has(key)) return qobuzCache.get(key);

  let out = null;
  try {
    // 1) Search
    const q = `${title} ${artist || ""}`.trim();
    await qobuzWait();
    const searchHtml = await httpText(
      `https://www.qobuz.com/us-en/search?q=${encodeURIComponent(q)}`,
      { "User-Agent": BROWSER_UA, "Accept-Language": "en-US,en;q=0.9" }
    );

    // 2) Find first album link whose URL slug contains both the album title
    //    word AND the artist word. Slug shape: /us-en/album/{slug}/{id}
    const linkRe = /\/(?:us-en\/)?album\/([^"'\/\s]+)\/([a-z0-9]+)/g;
    const seen = new Map();
    let m;
    while ((m = linkRe.exec(searchHtml)) !== null) {
      if (!seen.has(m[2])) seen.set(m[2], m[1]);
    }
    if (seen.size === 0) { qobuzCache.set(key, null); return null; }

    const titleFirst  = normalize(title).split(" ")[0];
    const artistFirst = normalize(artist || "").split(" ")[0];
    let chosenSlug = null, chosenId = null;
    for (const [id, slug] of seen) {
      const sn = slug.toLowerCase();
      if (titleFirst  && !sn.includes(titleFirst))  continue;
      if (artistFirst && !sn.includes(artistFirst)) continue;
      chosenSlug = slug; chosenId = id; break;
    }
    if (!chosenSlug) { qobuzCache.set(key, null); return null; }

    // 3) Fetch the album page
    await qobuzWait();
    const albumUrl = `https://www.qobuz.com/us-en/album/${chosenSlug}/${chosenId}`;
    const albumHtml = await httpText(albumUrl, {
      "User-Agent": BROWSER_UA, "Accept-Language": "en-US,en;q=0.9"
    });

    // 4) Editorial review.  Page has "Album Review: ..." heading, then the
    //    body, ending around "About the album" or "Improve album information".
    let review = null;
    const startMatch = /Album Review[:\s]/i.exec(albumHtml);
    if (startMatch) {
      const start = startMatch.index;
      const ends = [
        albumHtml.indexOf("About the album",          start),
        albumHtml.indexOf("Improve album information", start),
        albumHtml.indexOf("Why buy on Qobuz",          start),
        start + 8000
      ].filter(n => n > start);
      const end = Math.min(...ends);
      let text = stripHtml(albumHtml.substring(start, end));
      // Drop the leading "Album Review: Artist - Album" line.
      text = text.replace(/^Album Review[^\n]*\n?/i, "").trim();
      // Drop the trailing "© Author/Qobuz" attribution line.
      text = text.replace(/\s*©\s*[^\n]*\/Qobuz\s*$/i, "").trim();
      if (text.length > 60) review = text;
    }

    // 5) Year + label
    let year = null, label = null;
    const rel = albumHtml.match(/Released\s+on\s+([\d\/]+)\s*by\s*<[^>]*>([^<]+)</i);
    if (rel) {
      const parts = rel[1].split("/");
      const yp = parts[parts.length - 1];
      year = yp.length === 2 ? "20" + yp : yp;
      label = rel[2].trim();
    }

    if (review || year || label) {
      out = {
        description: review,
        year, label,
        url: albumUrl,
        source: "Qobuz"
      };
    }
  } catch (e) {
    if (DEBUG) console.error("[qobuz]", e.message);
  }

  qobuzCache.set(key, out);
  return out;
}

// Wikipedia: search + first-paragraph extract via the MediaWiki API.
async function wikiSearch(query, limit = 5) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search` +
    `&srsearch=${encodeURIComponent(query)}&srlimit=${limit}&format=json&origin=*`;
  const data = await httpJson(url, { "User-Agent": MB_USER_AGENT });
  return (data && data.query && data.query.search) || [];
}
async function wikiExtract(pageTitle) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&prop=extracts|info` +
    `&exintro=true&explaintext=true&redirects=1&inprop=url` +
    `&titles=${encodeURIComponent(pageTitle)}&format=json&origin=*`;
  const data = await httpJson(url, { "User-Agent": MB_USER_AGENT });
  const pages = (data && data.query && data.query.pages) || {};
  const page = pages[Object.keys(pages)[0]];
  if (!page || !page.extract) return null;
  return {
    title:       page.title,
    description: page.extract,
    url:         page.fullurl ||
                 `https://en.wikipedia.org/wiki/${encodeURIComponent(String(page.title).replace(/ /g, "_"))}`
  };
}

async function fetchWikiAlbum(title, artist) {
  if (!title) return null;
  const titleN      = normalize(title);
  const artistFirst = normalize(artist || "").split(" ")[0];
  const candidates  = await wikiSearch(`${title} ${artist || ""} album`);

  for (const c of candidates) {
    const ext = await wikiExtract(c.title);
    if (!ext) continue;

    const lead     = ext.description.slice(0, 400);
    const headNorm = normalize(ext.description.slice(0, 800));
    const titleNorm = normalize(c.title);

    // (1) The article must actually be about THIS album: its Wikipedia title
    //     should contain the album name as whole words (e.g. "Pang (album)",
    //     "Everything Forever (Victories at Sea album)").  Padding with spaces
    //     makes this a whole-word check so a short title like "Up" doesn't
    //     match "Group" / "Setup".
    const pad = s => " " + s + " ";
    if (!pad(titleNorm).includes(pad(titleN))) continue;

    // (2) Reject person biographies.  These slipped through before because a
    //     musician's bio mentions "albums" ("recorded five studio albums").
    //     Tell-tale signs: a birth/death date in parentheses, or "is/was a …
    //     singer/musician/band" in the lead.
    const personBirthDeath = /\(\s*(born\s+)?\d{1,2}\s+\w+\s+\d{4}\b/i.test(lead)
                          || /\b\d{4}\s*[–—-]\s*\d{4}\b/.test(lead);
    const personDescriptor = /\b(is|was)\s+(an?\s+)?(scottish|american|english|british|irish|welsh|canadian|australian|[a-z]+)?\s*(singer|songwriter|musician|guitarist|drummer|rapper|composer|producer|vocalist|bassist|pianist|dj|band|duo)\b/i.test(lead);
    if (personBirthDeath || personDescriptor) continue;

    // (3) Confirm it reads like a release: "… is/was the … album/EP/record …"
    if (!/\b(is|was)\b[^.]{0,80}\b(album|ep|record|mixtape|soundtrack|single)\b/i.test(lead)) continue;

    // (4) If we know the artist, prefer an article that mentions them.
    if (artistFirst && artistFirst.length > 2 && !headNorm.includes(artistFirst)) continue;

    return { ...ext, source: "Wikipedia" };
  }
  return null;
}
async function fetchWikiArtist(name) {
  if (!name) return null;
  const primary = name.split(",")[0].trim();
  const candidates = await wikiSearch(`${primary} band musician singer`);
  for (const c of candidates) {
    if (/\b(album|song|tour|discography)\b/i.test(c.title)) continue;
    const ext = await wikiExtract(c.title);
    if (!ext) continue;
    const head = ext.description.slice(0, 800);
    if (!/\b(band|musician|singer|songwriter|group|musical|guitarist|drummer|pianist|composer|rapper|vocalist|recording artist|duo|trio|quartet|ensemble|orchestra)\b/i.test(head)) continue;
    return { ...ext, name: ext.title, source: "Wikipedia" };
  }
  return null;
}

async function fetchWikipedia(title, artist) {
  if (!title) return null;
  const key = normalize(title) + "||" + normalize(artist || "");
  if (wikiCache.has(key)) return wikiCache.get(key);
  let result = null;
  try {
    const [album, artistInfo] = await Promise.all([
      fetchWikiAlbum(title, artist).catch(() => null),
      artist ? fetchWikiArtist(artist).catch(() => null) : Promise.resolve(null)
    ]);
    if (album || artistInfo) result = { album, artist: artistInfo };
  } catch (e) {
    if (DEBUG) console.error("[wiki]", e.message);
  }
  wikiCache.set(key, result);
  return result;
}

// Combine: Qobuz preferred for the album review; Wikipedia for the artist
// (and as fallback for the album when Qobuz has nothing).
async function fetchAlbumBios(title, artist) {
  if (!title) return null;
  const [qobuz, wiki] = await Promise.all([
    fetchQobuz(title, artist).catch(() => null),
    fetchWikipedia(title, artist).catch(() => null)
  ]);

  let album = null;
  if (qobuz && qobuz.description) {
    album = {
      description: qobuz.description,
      year:        qobuz.year  || (wiki && wiki.album && /(\d{4})/.exec(wiki.album.description || "") || [])[1] || null,
      label:       qobuz.label || null,
      url:         qobuz.url,
      source:      "Qobuz"
    };
  } else if (wiki && wiki.album) {
    album = {
      description: wiki.album.description,
      year:        null,
      label:       qobuz && qobuz.label ? qobuz.label : null,
      url:         wiki.album.url,
      source:      "Wikipedia"
    };
  } else if (qobuz) {
    // Qobuz had year/label but no review
    album = {
      description: null,
      year:  qobuz.year, label: qobuz.label,
      url:   qobuz.url,  source: "Qobuz"
    };
  }

  const artistObj = (wiki && wiki.artist) ? {
    name:        wiki.artist.name || artist || null,
    description: wiki.artist.description,
    url:         wiki.artist.url,
    source:      "Wikipedia"
  } : null;

  return { album, artist: artistObj };
}

// ---------------------------------------------------------------------------
// Express HTTP API
// ---------------------------------------------------------------------------
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (req, res) => {
  res.json({
    paired:    !!core,
    core_id:   core ? core.core_id      : null,
    core_name: core ? core.display_name : null,
    zone_count: Object.keys(zones).length
  });
});

app.get("/api/zones", (req, res) => {
  const list = Object.values(zones).map(z => ({
    zone_id:      z.zone_id,
    display_name: z.display_name,
    state:        z.state,
    outputs: (z.outputs || []).map(o => ({
      output_id: o.output_id, display_name: o.display_name
    }))
  })).sort((a, b) => a.display_name.localeCompare(b.display_name));
  res.json({ zones: list });
});

app.get("/api/random-albums", async (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core yet" });
  const count = Math.max(1, Math.min(96, parseInt(req.query.count || ALBUM_COUNT_DEFAULT, 10)));
  try {
    const albums = await pickRandomAlbums(count);
    res.json({ albums });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/image/:image_key", async (req, res) => {
  if (!core) return res.status(503).end();
  const size = Math.max(64, Math.min(1200, parseInt(req.query.size || "400", 10)));
  try {
    const { content_type, body } = await getImage(req.params.image_key, {
      scale: "fit", width: size, height: size, format: "image/jpeg"
    });
    res.set("Content-Type", content_type || "image/jpeg");
    res.set("Cache-Control", "public, max-age=86400");
    res.send(body);
  } catch (e) {
    res.status(404).end();
  }
});

// Album detail: requires ?offset=N
app.get("/api/album", async (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core yet" });
  const offset = parseInt(req.query.offset, 10);
  if (!Number.isFinite(offset) || offset < 0) {
    return res.status(400).json({ error: "Valid offset query parameter required" });
  }
  try {
    const r = await openAlbumByOffset(offset, null, null);
    res.json({
      album:  r.album,
      tracks: r.tracks,
      actions: r.actions.map(a => ({ kind: a.kind, title: a.title }))
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Library stats — currently just the total album count Roon reports for the
// "albums" hierarchy.  Shown in the header so you know the size of the pool
// random picks are drawn from.
let _albumCountCache = { value: null, at: 0 };
app.get("/api/library-stats", async (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core yet" });
  try {
    // Cache for 60s so repeated header loads don't re-walk the hierarchy.
    const now = Date.now();
    if (_albumCountCache.value != null && now - _albumCountCache.at < 60000) {
      return res.json({ albums: _albumCountCache.value, cached: true });
    }
    const sessionKey = "rra_stats_" + Math.random().toString(36).slice(2, 10);
    await browse({ hierarchy: "albums", pop_all: true, multi_session_key: sessionKey });
    const head = await load({
      hierarchy: "albums", offset: 0, count: 1, multi_session_key: sessionKey
    });
    const total = head.list && head.list.count ? head.list.count : 0;
    _albumCountCache = { value: total, at: now };
    res.json({ albums: total });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Album metadata extras: release year (MusicBrainz) + bios (Discogs).
// Frontend passes title and artist so we don't hit Roon twice per modal open.
app.get("/api/album/extras", async (req, res) => {
  const title  = String(req.query.title  || "");
  const artist = String(req.query.artist || "");
  if (!title) return res.status(400).json({ error: "title query parameter required" });
  try {
    const [year, bios] = await Promise.all([
      fetchAlbumYear(title, artist),
      fetchAlbumBios(title, artist)
    ]);
    res.json({
      year,
      album:  bios ? bios.album  : null,
      artist: bios ? bios.artist : null
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Debug endpoint: dumps the raw items returned by Roon when drilling into an
// album.  Visit http://<host>:3399/api/debug/album?offset=N in your browser.
app.get("/api/debug/album", async (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core yet" });
  const offset = parseInt(req.query.offset, 10);
  if (!Number.isFinite(offset) || offset < 0) {
    return res.status(400).json({ error: "Valid offset query parameter required" });
  }
  const sessionKey = "rra_dbg_" + Math.random().toString(36).slice(2, 10);
  try {
    await browse({ hierarchy: "albums", pop_all: true, multi_session_key: sessionKey });
    const albumLoad = await load({
      hierarchy: "albums", offset, count: 1, multi_session_key: sessionKey
    });
    const albumItem = albumLoad.items && albumLoad.items[0];
    if (!albumItem) return res.status(404).json({ error: "Album not found at offset" });

    await browse({
      hierarchy: "albums",
      item_key:  albumItem.item_key,
      multi_session_key: sessionKey
    });
    const inside = await load({
      hierarchy: "albums",
      offset: 0,
      count: 500,
      multi_session_key: sessionKey
    });
    res.json({
      album: { title: albumItem.title, subtitle: albumItem.subtitle },
      list:  inside.list,
      item_count_returned: (inside.items || []).length,
      items: (inside.items || []).map(it => ({
        title: it.title,
        subtitle: it.subtitle,
        hint: it.hint || null,
        has_image: !!it.image_key,
        item_key_present: !!it.item_key
      }))
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Play an album: body { offset, zone_or_output_id, kind }
app.post("/api/play", async (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core yet" });
  const { offset, zone_or_output_id, kind } = req.body || {};
  if (!Number.isFinite(offset)) return res.status(400).json({ error: "offset required" });
  if (!zone_or_output_id)       return res.status(400).json({ error: "zone_or_output_id required" });
  if (!kind)                    return res.status(400).json({ error: "kind required" });
  try {
    await openAlbumByOffset(offset, zone_or_output_id, kind);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------------------------------------------------------------------------
// Mini-transport: live now-playing for a zone + playback / volume control
// ---------------------------------------------------------------------------

// Resolve the currently playing album for a zone, via Roon's browse hierarchy
// (search → Albums → matching item). Returns tracks + the bio shape used by
// the album modal.  If anything fails, returns the basic info we already have
// from now_playing so the modal still works (no tracks but no error either).
async function findNowPlayingAlbum(zoneId) {
  if (!core) throw new Error("Not paired with Roon Core");
  const zone = zones[zoneId];
  if (!zone || !zone.now_playing) throw new Error("Nothing playing in this zone");

  const tl    = zone.now_playing.three_line || {};
  const title = tl.line3 || (zone.now_playing.one_line && zone.now_playing.one_line.line1) || "";
  const artist= tl.line2 || "";
  const image = zone.now_playing.image_key || null;

  const fallback = {
    album:  { title, subtitle: artist, image_key: image },
    tracks: []
  };
  if (!title) return fallback;

  const sessionKey = "rra_np_" + Math.random().toString(36).slice(2, 10);
  const hier = "browse";

  try {
    // Root with EXPLICIT count: 100 — without this the search entry can be on
    // a later page and we never see it.
    await browse({ hierarchy: hier, pop_all: true, multi_session_key: sessionKey, zone_or_output_id: zoneId });
    const root = await load({ hierarchy: hier, offset: 0, count: 100, multi_session_key: sessionKey });
    const items0 = root.items || [];

    const searchItem = items0.find(i => i.input_prompt)
                    || items0.find(i => /search/i.test(i.title || ""));
    if (!searchItem) {
      if (DEBUG) console.log("[np] no search at root, items were:",
        items0.map(i => ({ title: i.title, hint: i.hint })));
      return fallback;
    }

    const query = `${title} ${artist}`.trim();
    await browse({
      hierarchy: hier, multi_session_key: sessionKey,
      item_key: searchItem.item_key, input: query, zone_or_output_id: zoneId
    });
    const results = await load({ hierarchy: hier, offset: 0, count: 100, multi_session_key: sessionKey });
    const sections = results.items || [];

    const albumsSection = sections.find(s => /album/i.test(s.title || "") && s.item_key);
    if (!albumsSection) return fallback;

    await browse({ hierarchy: hier, multi_session_key: sessionKey, item_key: albumsSection.item_key });
    const albs = await load({ hierarchy: hier, offset: 0, count: 50, multi_session_key: sessionKey });

    const titleN  = title.toLowerCase().trim();
    const artistN = artist.toLowerCase().trim();
    const albumItem =
         (albs.items || []).find(i => (i.title || "").toLowerCase() === titleN
                                    && (i.subtitle || "").toLowerCase().includes(artistN))
      || (albs.items || []).find(i => (i.title || "").toLowerCase() === titleN)
      || (albs.items || []).find(i => (i.title || "").toLowerCase().includes(titleN))
      || (albs.items || [])[0];
    if (!albumItem || !albumItem.item_key) return fallback;

    await browse({ hierarchy: hier, multi_session_key: sessionKey, item_key: albumItem.item_key });
    const inside = await load({ hierarchy: hier, multi_session_key: sessionKey, offset: 0, count: 500 });
    const items = inside.items || [];

    const playMenu = items.find(i => i.hint === "action_list" && !i.subtitle && /^play/i.test(i.title || ""))
                  || items.find(i => i.hint === "action_list" && !i.subtitle);
    const tracks = items
      .filter(t => {
        if (t === playMenu) return false;
        if (t.hint === "action_list" && !t.subtitle) return false;
        if (t.hint === "header") return false;
        return true;
      })
      .map(t => ({
        title:    (t.title || "").replace(/^\d+\.\s+/, ""),
        subtitle: t.subtitle || ""
      }));

    return {
      album: {
        title:     albumItem.title    || title,
        subtitle:  albumItem.subtitle || artist,
        image_key: albumItem.image_key || image
      },
      tracks
    };
  } catch (e) {
    if (DEBUG) console.error("[np lookup]", e.message);
    return fallback;
  }
}

app.get("/api/album/now-playing", async (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const zoneId = req.query.zone;
  if (!zoneId) return res.status(400).json({ error: "zone required" });
  try {
    const r = await findNowPlayingAlbum(zoneId);
    res.json(r);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Queue for a zone
// RoonApiTransport doesn't expose a one-shot get_queue — only subscribe_queue.
// We subscribe, respond on the first "Subscribed" payload, and accept that the
// subscription leaks for the lifetime of the process (acceptable for occasional
// modal opens; a future revision could keep one persistent subscription per zone).
app.get("/api/queue", (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const zoneId = req.query.zone;
  if (!zoneId) return res.status(400).json({ error: "zone required" });

  let responded = false;
  const timeout = setTimeout(() => {
    if (responded) return;
    responded = true;
    res.status(504).json({ error: "queue subscription timed out" });
  }, 5000);

  try {
    core.services.RoonApiTransport.subscribe_queue(zoneId, 100, (response, msg) => {
      if (responded) return;
      if (response === "Subscribed") {
        responded = true;
        clearTimeout(timeout);
        const items = ((msg && msg.items) || []).map(it => ({
          queue_item_id: it.queue_item_id,
          title:    (it.one_line && it.one_line.line1) || (it.three_line && it.three_line.line1) || "",
          subtitle: (it.three_line && it.three_line.line2) || "",
          image_key: it.image_key || null,
          length:    it.length || null
        }));
        res.json({ items });
      }
    });
  } catch (e) {
    if (!responded) {
      responded = true;
      clearTimeout(timeout);
      res.status(500).json({ error: e.message || String(e) });
    }
  }
});

app.get("/api/zone-state", (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const zoneId = req.query.zone;
  const zone   = zoneId && zones[zoneId];
  if (!zone) return res.json({ zone: null });

  const np = zone.now_playing || null;
  const tl = (np && np.three_line) || {};
  const ol = (np && np.one_line)   || {};

  res.json({
    zone: {
      zone_id:             zone.zone_id,
      display_name:        zone.display_name,
      state:               zone.state,  // "playing" | "paused" | "loading" | "stopped"
      is_play_allowed:     !!zone.is_play_allowed,
      is_pause_allowed:    !!zone.is_pause_allowed,
      is_next_allowed:     !!zone.is_next_allowed,
      is_previous_allowed: !!zone.is_previous_allowed,
      outputs: (zone.outputs || []).map(o => ({
        output_id:    o.output_id,
        display_name: o.display_name,
        is_muted:     !!o.is_muted,
        volume:       o.volume ? {
          value:      o.volume.value,
          min:        o.volume.min,
          max:        o.volume.max,
          step:       o.volume.step,
          soft_limit: o.volume.soft_limit,
          type:       o.volume.type
        } : null
      })),
      now_playing: np ? {
        line1:     tl.line1 || ol.line1 || "",   // track
        line2:     tl.line2 || "",               // artist
        line3:     tl.line3 || "",               // album
        image_key: np.image_key || null,
        length:    np.length || null,
        seek_position: np.seek_position || null
      } : null
    }
  });
});

// Playback control.  body: { zone_or_output_id, command }
// command ∈ play | pause | playpause | stop | previous | next
app.post("/api/control", (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const { zone_or_output_id, command } = req.body || {};
  if (!zone_or_output_id) return res.status(400).json({ error: "zone_or_output_id required" });
  const allowed = ["play", "pause", "playpause", "stop", "previous", "next"];
  if (!allowed.includes(command)) {
    return res.status(400).json({ error: "invalid command, allowed: " + allowed.join(", ") });
  }
  core.services.RoonApiTransport.control(zone_or_output_id, command, (err) => {
    if (err) return res.status(500).json({ error: typeof err === "string" ? err : JSON.stringify(err) });
    res.json({ ok: true });
  });
});

// Transfer zone: move the currently playing queue from one zone to another.
// body: { from_zone, to_zone }
app.post("/api/transfer-zone", (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const { from_zone, to_zone } = req.body || {};
  if (!from_zone || !to_zone) return res.status(400).json({ error: "from_zone and to_zone required" });
  if (from_zone === to_zone) return res.json({ ok: true, noop: true });

  const fromName = (zones[from_zone] && zones[from_zone].display_name) || from_zone;
  const toName   = (zones[to_zone]   && zones[to_zone].display_name)   || to_zone;
  console.log(`[transfer-zone] ${fromName} → ${toName}`);

  core.services.RoonApiTransport.transfer_zone(from_zone, to_zone, (err) => {
    if (err) {
      const msg = typeof err === "string" ? err : JSON.stringify(err);
      console.warn(`[transfer-zone] failed: ${msg}`);
      return res.status(500).json({ error: msg });
    }
    console.log(`[transfer-zone] ok`);
    res.json({ ok: true });
  });
});

// Play from a specific queue item onwards.
// body: { zone_or_output_id, queue_item_id }
app.post("/api/play-from-here", (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const { zone_or_output_id, queue_item_id } = req.body || {};
  if (!zone_or_output_id || queue_item_id === undefined || queue_item_id === null) {
    return res.status(400).json({ error: "zone_or_output_id and queue_item_id required" });
  }
  core.services.RoonApiTransport.play_from_here(zone_or_output_id, queue_item_id, (err) => {
    if (err) {
      const msg = typeof err === "string" ? err : JSON.stringify(err);
      console.warn(`[play-from-here] failed: ${msg}`);
      return res.status(500).json({ error: msg });
    }
    res.json({ ok: true });
  });
});

// Volume.  body: { zone_or_output_id, value?, mute?, relative? }
//   value:    absolute volume to set (uses output's native scale)
//   relative: signed delta to add (e.g. +5, -5)
//   mute:     true/false
// For a zone, applies to every output in the zone.
app.post("/api/volume", (req, res) => {
  if (!core) return res.status(503).json({ error: "Not paired with Roon Core" });
  const { zone_or_output_id } = req.body || {};
  if (!zone_or_output_id) return res.status(400).json({ error: "zone_or_output_id required" });

  // Figure out which outputs to target
  const zone = zones[zone_or_output_id];
  const targetOutputs = zone
    ? (zone.outputs || []).map(o => o)
    : (outputs[zone_or_output_id] ? [outputs[zone_or_output_id]] : []);
  if (targetOutputs.length === 0) return res.status(404).json({ error: "no outputs found" });

  const t = core.services.RoonApiTransport;
  const tasks = [];

  if (req.body.mute !== undefined) {
    const how = req.body.mute ? "mute" : "unmute";
    for (const o of targetOutputs) {
      tasks.push(new Promise((resolve, reject) =>
        t.mute(o.output_id, how, err => err ? reject(err) : resolve())));
    }
  } else if (req.body.value !== undefined) {
    const v = parseFloat(req.body.value);
    for (const o of targetOutputs) {
      tasks.push(new Promise((resolve, reject) =>
        t.change_volume(o.output_id, "absolute", v, err => err ? reject(err) : resolve())));
    }
  } else if (req.body.relative !== undefined) {
    const v = parseFloat(req.body.relative);
    for (const o of targetOutputs) {
      tasks.push(new Promise((resolve, reject) =>
        t.change_volume(o.output_id, "relative", v, err => err ? reject(err) : resolve())));
    }
  } else {
    return res.status(400).json({ error: "value, relative, or mute required" });
  }

  Promise.all(tasks)
    .then(() => res.json({ ok: true }))
    .catch(err => res.status(500).json({
      error: typeof err === "string" ? err : JSON.stringify(err)
    }));
});

app.listen(PORT, () => {
  console.log("Roon Random Albums UI listening on http://0.0.0.0:" + PORT);
  console.log("Make sure to authorise the extension in Roon → Settings → Extensions.");
  if (DEBUG) console.log("Debug logging enabled (RRA_DEBUG=1).");
});
